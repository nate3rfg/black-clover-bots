# Black Clover Discord Bots

5 bots, each a separate Discord Application:

1. **Roast Battle Bot** — `/battle`, `/leaderboard`, `/stats`, `/forfeit`, `/reset`
2. **Asta Bot** — only replies in your Asta channel
3. **Noelle Bot** — only replies in your Noelle channel (tsundere)
4. **Zora Bot** — only replies in your Zora channel (rude/blunt)
5. **Klaus Bot** — replies anywhere it's @mentioned, can create channels on request
6. **Nero Bot** (human form) — only replies in your Nero channel (reserved/deadpan)

All chat is generated live via the Anthropic (Claude) API. Each persona/tsundere/rude
bot has a `/reset` command that clears its short-term memory if it starts acting weird.

## Important — about "24/7" hosting

I can write and hand you fully working code, but I can't personally keep a process
running for you around the clock — this conversation and its sandbox don't stay
alive after we're done, and I have no ability to host a live Discord gateway
connection on your behalf. For real 24/7/365 uptime you need to run this on a
machine that stays on, such as:

- A cheap VPS (Hetzner, DigitalOcean, Contabo, etc.) — most reliable option
- A platform like Railway, Render, or Fly.io (some have free/low tiers, check current pricing)
- A Raspberry Pi or always-on home PC (fine for personal servers)

Whatever you pick, use the included `ecosystem.config.js` with **pm2** (see below) —
that gives you auto-restart if a bot crashes or the process gets killed, which is
what actually gets you "never offline" in practice (discord.js itself already
auto-reconnects on network hiccups).

## 1. Create 5 Discord Applications

For **each** bot (Roast Battle, Asta, Noelle, Zora, Klaus, Nero):

1. Go to https://discord.com/developers/applications → **New Application**
2. Go to **Bot** tab → **Reset Token** → copy it (this is your `*_BOT_TOKEN`)
3. Turn ON **Message Content Intent** under Privileged Gateway Intents (all 5 bots need this)
4. Copy the **Application ID** from the General Information tab (this is your `*_CLIENT_ID`)
5. Go to **OAuth2 → URL Generator**, check `bot` and `applications.commands` scopes, and under Bot Permissions check:
   - Send Messages, Read Message History, Use Slash Commands, Embed Links — for all 6
   - **Manage Channels** — additionally required for **Klaus** only (so he can create channels)
6. Open the generated URL and invite each bot to your server (guild id `1526822886994608170` based on your links)

## 2. Get an Anthropic API key

Create a key at https://console.anthropic.com (this is a paid, usage-billed API —
running 5 always-on chat bots will incur ongoing API costs, so keep an eye on usage).

## 3. Configure environment variables

```
cp .env.example .env
```

Fill in all 6 bot tokens/client IDs and your Anthropic API key. The `GUILD_ID` and
the persona channel IDs are already pre-filled based on the channel links you gave me —
double check they're right for your server.

## 4. Install dependencies

```
npm install
```

## 5. Register slash commands

```
npm run deploy-commands
```

Run this once initially, and again any time you change a command's definition.

## 6. Run it

For local testing:
```
npm start
```

For real 24/7 uptime on a server, use **pm2**:
```
npm install -g pm2
pm2 start ecosystem.config.js
pm2 save
pm2 startup   # follow the printed instructions so pm2 restarts on server reboot too
```

Useful pm2 commands: `pm2 logs`, `pm2 restart black-clover-bots`, `pm2 status`.

## How each bot works

- **Roast Battle**: `/battle @user` posts a challenge with Accept/Decline buttons
  (60s to respond). On accept, both fighters have 120 seconds to post roast lines
  in the channel; every message from either fighter during that window counts.
  When time's up, Claude judges the exchange purely on comedic/roast quality (not
  on anyone's real traits) and picks a winner with reasoning. Wins/losses are
  saved to `data/battle-stats.json`. `/forfeit` ends your current battle early
  (auto-loss), `/reset` force-clears a stuck battle in a channel if the bot ever
  gets stuck mid-fight.
- **Asta / Noelle / Zora / Nero**: each only listens in its one configured channel, holds
  a short rolling memory of recent messages in that channel for context, and
  replies in character. `/reset` wipes that channel's memory.
- **Klaus**: listens for @mentions in *any* channel. Normal conversation gets an
  in-character reply; if you ask him to create a channel (e.g.
  `@Klaus create a channel called strategy-room`), he uses a tool call to
  actually create it via the Discord API, then confirms in character. `/reset`
  wipes his memory.

## Tuning personas / adjustments

Each persona's system prompt lives at the top of its file in `bots/`
(`astaBot.js`, `noelleBot.js`, `zoraBot.js`, `klausBot.js`, `neroBot.js`) — edit the `persona`
string directly to adjust tone, verbosity, or behavior. The roast judge's
instructions live in `judgeBattle()` inside `bots/roastBattleBot.js`.
