module.exports = {
  apps: [
    {
      name: 'black-clover-bots',
      script: 'index.js',
      autorestart: true,
      max_restarts: 50,
      restart_delay: 5000,
      watch: false,
      env: {
        NODE_ENV: 'production',
      },
    },
  ],
};
